import re
from datetime import datetime
from pprint import pprint

import time, math
import re
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.wait import WebDriverWait
import traceback
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
import requests
import random
import json

from lmf.dbv2 import db_command,db_write,db_query
from login import get_driver
from threading import Semaphore
sema=Semaphore()


def get_all_href(conp):
    sema.acquire()
    user, passwd, host, dbname, schema = conp
    sql='''select distinct main_href from "%s".ext_href_main as a  where  not exists (select 1 from "%s".ext_href_status as b where a.main_href=b.main_href ) and a.status='缺失' limit 10'''%(schema,schema)
    href_list=db_query(sql,dbtype="postgresql",conp=conp)["main_href"].tolist()
    sema.release()
    return href_list



def get_status(driver,main_href):
    shixiao_title_mark=["404","503","403"]
    shixiao_page_mark=["无法访问此网站","网页无法正常运作","<head></head><body></body>"]

    driver.get(main_href)
    WebDriverWait(driver, 10).until(lambda driver: "http" in driver.current_url)

    for mark  in shixiao_title_mark:
        if mark  in  driver.title:return "失效",""

    for mark in shixiao_page_mark:
        if mark in driver.page_source:return "失效",""

    title=driver.title
    status = "有效"

    return status,title



def check(conp,driver,main_href):
    user, passwd, host, dbname, schema = conp

    status,title = get_status(driver,main_href)
    now_t = datetime.now().strftime("%Y-%m-%d %H:%M")
    sql1 = '''insert into %s.ext_href_status values($lch$%s$lch$,$lch$%s$lch$,$lch$%s$lch$,$lch$%s$lch$)''' % (
    schema,title,main_href, status, now_t)
    db_command(sql1, dbtype="postgresql", conp=conp)
    print("插入成功:%s"%main_href)


def work(conp,headless=False):
    driver=get_driver(headless=headless,image_show=2,pageloadtimeout=80,pageloadstrategy='none')
    while True:
        href_list=get_all_href(conp)
        if not href_list:break
        for href in href_list:
            print("正在判断 [%s]"%href)
            try:
                check(conp,driver,href)
            except:
                driver.quit()
                driver=get_driver(headless=headless,image_show=2,pageloadtimeout=80,pageloadstrategy='none')

        print('完成10个提取')


def append(main_href,status,conp,title=None):
    user, passwd, host, dbname, schema = conp
    now_t = datetime.now().strftime("%Y-%m-%d %H:%M")
    sql1 = '''insert into %s.ext_href_status values($lch$%s$lch$,$lch$%s$lch$,$lch$%s$lch$,$lch$%s$lch$)''' % (
        schema, title,main_href, status, now_t)
    db_command(sql1, dbtype="postgresql", conp=conp)
    print("添加成功")

def update(main_href,status,conp):
    user, passwd, host, dbname, schema = conp
    now_t = datetime.now().strftime("%Y-%m-%d %H:%M")
    sql1 = '''update %s.ext_href_status set status ='%s' and create_time=$lch$%s$lch$ where main_href=$lch$%s$lch$''' % (
        schema, status, now_t,main_href)
    print(sql1)
    db_command(sql1, dbtype="postgresql", conp=conp)
    print("修改成功")

def delete(main_href,conp):
    user, passwd, host, dbname, schema = conp
    sql1 = '''delete from  %s.ext_href_status where main_href=$lch$%s$lch$''' % (
        schema, main_href)
    print(sql1)
    db_command(sql1, dbtype="postgresql", conp=conp)
    print("删除成功")


if __name__ == '__main__':
    """
    create table if not exists ext_href_status(title text,main_href text,status text, create_time text,info text COLLATE "default" DEFAULT '未添加至总表'::text,primary key(main_href))
    """

    conp = ["postgres", "since2015", "192.168.1.171", "postgres", "jianyu"]
    work(conp)
    # append(main_href="http://cz.newhope.cn/",status="有效",conp=conp)
    # update(main_href="http://61.50.130.200",status="有效",conp=conp)