from pprint import pprint
import os
from selenium import webdriver
import time, math
import re
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.wait import WebDriverWait
import traceback
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
import requests
from selenium.common.exceptions import WebDriverException
from selenium.common.exceptions import NoSuchElementException
from threading import Semaphore
from lmf.dbv2 import db_write
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from lmfscrap.fake_useragent import UserAgent
import random
import json


ua=UserAgent()
sema=Semaphore()

def get_driver(ip=None,headless=False,image_show=1,pageloadtimeout=60,pageloadstrategy="normal"):
    print("当前ip:%s"%str(ip))
    chrome_option = webdriver.ChromeOptions()
    if ip: chrome_option.add_argument("--proxy-server=http://%s" % (ip))

    if headless:
        chrome_option.add_argument("--headless")
        chrome_option.add_argument("--no-sandbox")
        chrome_option.add_argument('--disable-gpu')

    prefs = {
        'profile.default_content_setting_values': {'images': image_show, }
    }

    chrome_option.add_experimental_option("prefs", prefs)

    caps = DesiredCapabilities().CHROME
    caps["pageLoadStrategy"] = pageloadstrategy
    args = {"desired_capabilities": caps, "chrome_options": chrome_option}
    driver = webdriver.Chrome(**args)
    driver.maximize_window()
    driver.set_page_load_timeout(pageloadtimeout)

    return driver

def get_ip():

    get_ip_url="http://zhulong.v4.dailiyun.com/query.txt?key=NPACB534AB&word=&count=1&rand=false&detail=false"

    # get_ip_url="http://ip.11jsq.com/index.php/api/entry?method=proxyServer.generate_api_url&packid=0&fa=0&fetch_key=&groupid=0&qty=1&time=1&pro=&city=&port=1&format=txt&ss=1&css=&dt=1&specialTxt=3&specialJson=&usertype=2"
    # print(self.get_ip_url)
    # get_ip_url="http://192.168.1.170/random"

    sema.acquire()
    i = 3
    try:
        url = get_ip_url
        r = requests.get(url, timeout=40, headers={'User-Agent': ua.random})
        time.sleep(1)
        ip = r.text
        while re.match("[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}:[0-9]{1,5}", ip) is None and i > 0:
            time.sleep(3 - i)
            i -= 1
            url = get_ip_url
            r = requests.get(url, timeout=40, headers={'User-Agent': ua.random})
            time.sleep(1)
            ip = r.text

    except:
        ip = {}
    finally:
        sema.release()
        if '登录IP不是白名单IP，请在用户中心添加该白名单. Please add ip to white list' in ip:
            print('ip 不在白名单')
            ip={}

    return ip.strip()


def write_cookies(filename,cookies):
    # cookie="\n".join(cookies)
    # print(cookies)

    con_head="[\n"
    con_cont=""
    con_foot="]"
    for cookie in cookies:
        con_cont +=str(cookie) + ",\n"

    content="".join([con_head,con_cont,con_foot])
    with open(filename,'w',encoding='utf8') as f:
        f.write("cookies_dict="+str(content))


def get_cookies(ip=None,clear_cookies=False):
    """
    获取 存储 cookies
    :param ip:
    :param clear_cookies: 是否删除已存的cookies
    :return:
    """
    driver=get_driver(ip=ip)

    login_url='https://www.jianyu360.com/jylab/supsearch/index.html'
    driver.get(login_url)

    locator = (By.XPATH, '//div[@class="lucene"]//li[1]//div[@class="left-title"]/a')
    WebDriverWait(driver, 40).until(EC.presence_of_element_located(locator))

    locator=(By.XPATH,'//button[@class="loginBtn"]')
    WebDriverWait(driver,10).until(EC.presence_of_element_located(locator)).click()

    locator=(By.XPATH,'//div[@class="userInfo"]')
    WebDriverWait(driver,100).until(EC.presence_of_element_located(locator))

    cookies=driver.get_cookies()
    if clear_cookies:
        os.system('cat  > COOKIES_driver.py')
        os.system('cat  > COOKIES_request.py')
    with open('COOKIES_driver.py','r',encoding='utf8') as f:

        driver_cookies_dict=f.read()
        driver_cookies_dict=driver_cookies_dict.strip('cookies_dict=').strip()
        print(driver_cookies_dict)
    with open('COOKIES_request.py','r',encoding='utf8') as f:

        request_cookies_dict=f.read()
        request_cookies_dict = request_cookies_dict.strip('cookies_dict=').strip()

    ## driver_cookies
    if driver_cookies_dict:
        driver_cookies_dict = eval(driver_cookies_dict)

        driver_cookies_dict.append(cookies)

    else:
        driver_cookies_dict = [cookies, ]

    ## request cookies
    COOKIES = {}
    for cookie in cookies:
        COOKIES[cookie['name']] = cookie['value']

    if request_cookies_dict:
        request_cookies_dict = eval(request_cookies_dict)
        request_cookies_dict.append(COOKIES)
    else:
        request_cookies_dict=[COOKIES,]

    # print(request_cookies_dict)

    ## 写入文件
    write_cookies("COOKIES_driver.py",driver_cookies_dict)
    write_cookies("COOKIES_request.py",request_cookies_dict)



if __name__ == '__main__':
    pass
    ip=get_ip()
    get_cookies(ip,clear_cookies=False)
    # get_cookies(ip,clear_cookies=True)
    # get_cookies()
    # driver=get_driver()
    # driver.get("https://www.jianyu360.com/jylab/supsearch/index.html")




