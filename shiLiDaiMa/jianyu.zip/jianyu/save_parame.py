
import itertools
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from bs4 import BeautifulSoup
from login import get_driver
from lmf.dbv2 import db_command,db_write
import pandas as pd

def save_parame(conp,):
    driver=get_driver()
    login_url='https://www.jianyu360.com/jylab/supsearch/index.html'
    driver.get(login_url)

    locator = (By.XPATH, '//div[@class="lucene"]//li[1]//div[@class="left-title"]/a')
    WebDriverWait(driver, 40).until(EC.presence_of_element_located(locator))

    soup=BeautifulSoup(driver.page_source,'lxml')
    driver.quit()
    industry_content=soup.find('div',class_='industry-content').find_all('font',attrs={"data-value":True})
    industrys_list=[]

    for industry in industry_content:
        industry=industry.get('data-value')
        industrys_list.append(industry)

    region_content=soup.find('div',class_='region-content').find_all('font')
    regions_list=[]
    for region in region_content:
        region=region.get_text(strip=True)
        regions_list.append(region)

    info_content=soup.find('div',class_='info-content').find_all('font',attrs={"data-value":True})
    infos_list=[]
    for info in info_content:
        info=info.get_text(strip=True)
        infos_list.append(info)

    parame_list=itertools.product(industrys_list,regions_list,infos_list,[321,])

    parames=pd.DataFrame(parame_list,columns=['jytype','area','ggtype','status'])
    db_write(parames,'parames',dbtype='postgresql',conp=conp,datadict="postgresql-text")


if __name__ == '__main__':
    conp = ["postgres", "since2015", "192.168.1.171", "postgres", "jianyu"]
    # save_parame(conp)


# print(industrys_list)
# print(regions_list)
# print(infos_list)

# for cookie in cookies_dict:
#     driver.add_cookie(cookie)

# driver.get(login_url)


