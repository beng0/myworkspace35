import json
import re
import time
import traceback

import requests
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from lmf.dbv2 import db_command,db_query,db_write
import pandas as pd
from threading import Semaphore
from datetime import datetime
import random
from queue import Queue
from threading import Thread

from bs4 import BeautifulSoup
from login import get_ip
from login import get_driver
from login import get_cookies
import COOKIES_driver
import importlib

sema=Semaphore()


def get_href(conp,total=10):
    user,passwd,host,dbname,schema=conp
    sql1='''select distinct href from "%s".gg as a  where  not exists (select 1 from "%s".gg_html as b where a.href=b.href ) limit %d'''%(schema,schema,total)
    parames=db_query(sql1,dbtype="postgresql",conp=conp).values.tolist()

    return parames


def get_data(driver,href):

    driver.get(href)
    html=driver.page_source

    if "未连接到互联网" in html or "无法访问此网站" in html or "<head></head><body></body>" in html:
        print("ip 失效")
        raise ConnectionError("ip 失效")
    try:
        locator = (By.XPATH, '//div[@class="original-text"]/a[contains(@href,"http")]')
        WebDriverWait(driver, 20).until(EC.presence_of_element_located(locator))
    except:

        if "验证码" in driver.title:
            print("验证码")
            print(datetime.now())
            locator = (By.XPATH, '//div[@class="original-text"]/a[contains(@href,"http")]')
            WebDriverWait(driver, 600).until(EC.presence_of_element_located(locator))
        else:
            locator = (By.XPATH, '//div[@class="modal fade in"][contains(@style,"block")]//img[@id="layerImg"]')
            WebDriverWait(driver, 5).until(EC.presence_of_element_located(locator))
            print("COOKIES 失效,需重新登录")
            driver.quit()
            get_cookies()

    time.sleep(0.1)
    soup=BeautifulSoup(driver.page_source,'lxml')
    ext_href=soup.find('div',class_="original-text").find('a').get('href')

    return ext_href

def chang_cookies(driver):
    ###重新加载cookies
    importlib.reload(COOKIES_driver)
    cookies_dict = random.choice(COOKIES_driver.cookies_dict)

    login_url = 'https://www.jianyu360.com/jylab/supsearch/index.html'
    driver.get(login_url)
    locator = (By.XPATH, '//div[@class="lucene"]//li[1]//div[@class="left-title"]/a')
    WebDriverWait(driver, 60).until(EC.presence_of_element_located(locator))
    driver.delete_all_cookies()
    for cookie in cookies_dict:
        if "expiry" in cookie.keys():  ##expiry 会报错
            cookie.pop('expiry')
        driver.add_cookie(cookie)
    print("切换COOKIES成功")
    return driver


def init_driver():
    ###重新加载cookies
    importlib.reload(COOKIES_driver)
    cookies_dict= random.choice(COOKIES_driver.cookies_dict)

    ips = get_ip()
    print("本次ip: %s"%ips)
    driver = get_driver(ip=ips,image_show=1,headless=False)
    login_url = 'https://www.jianyu360.com/jylab/supsearch/index.html'
    driver.get(login_url)
    locator = (By.XPATH, '//div[@class="lucene"]//li[1]//div[@class="left-title"]/a')
    WebDriverWait(driver, 60).until(EC.presence_of_element_located(locator))
    driver.delete_all_cookies()
    for cookie in cookies_dict:
        if "expiry" in cookie.keys(): ##expiry 会报错
            cookie.pop('expiry')
        driver.add_cookie(cookie)
    print("添加COOKIES成功")
    return driver

def work(driver,href,conp):
    user, passwd, host, dbname, schema = conp
    time.sleep(random.random()+5)

    driver=chang_cookies(driver) ## 变cookies

    ext_href=get_data(driver,href)
    now_t=datetime.now().strftime("%Y-%m-%d %H:%M")
    sql1 = '''insert into %s.gg_html values($lch$%s$lch$,$lch$%s$lch$,$lch$%s$lch$)'''%(schema,href,ext_href,now_t)
    db_command(sql1,dbtype="postgresql", conp=conp)



hrefQ=Queue()
def get_href_q(conp):
    hrefs=get_href(conp,1000)
    for href in hrefs:hrefQ.put(href)


def threadwork(conp):

    driver = init_driver()
    count=0
    while not hrefQ.empty():
        sema.acquire()
        href = hrefQ.get()
        href=href[0]
        sema.release()
        count +=1
        try:
            work(driver,href,conp)
        except:
            traceback.print_exc()
            driver.quit()
            print('链接 %s  出错' % (href))
            driver = init_driver()

        if count % 10 == 0:
            print("完成10个链接提取")



def threadrun(conp,num=1):
    tlist=[]
    for i in range(num):
        t=Thread(target=threadwork,args=(conp,))
        tlist.append(t)
    for t in tlist:
        t.start()
    for t in tlist:
        t.join()

def run(conp,num=1):
    get_href_q(conp)
    threadrun(conp,num)

if __name__ == '__main__':
    """
    create table if not exists gg_html(href text,ext_href text,create_time text,primary key(href))
    """

    conp = ["postgres", "since2015", "192.168.1.171", "postgres", "jianyu"]
    run(conp)
