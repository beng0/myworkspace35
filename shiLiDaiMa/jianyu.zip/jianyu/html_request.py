import json
import re
import time

import requests
from lmf.dbv2 import db_command,db_query,db_write
from zlsrc.util.fake_useragent import UserAgent
import pandas as pd
from threading import Semaphore
from datetime import datetime
import random
from bs4 import BeautifulSoup
from login import get_ip
from urllib import parse
from login import get_cookies

sema=Semaphore()
ua=UserAgent()


headers={

"Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
"Accept-Encoding": "gzip, deflate, br",
"Accept-Language": "zh-CN,zh;q=0.9",
"Cache-Control": "max-age=0",
"Connection": "keep-alive",
# "Cookie": "UM_distinctid=16cb716e6e485-03db467d55ee4e-4f4c0a2e-1fa400-16cb716e6e5751; Hm_lvt_72331746d85dcac3dac65202d103e5d9=1575249968,1575249978,1575252406,1575337398; SESSIONID=18a2e50aa519c41f5df27c391ecc8f26881f6b28; SESSIONID=18a2e50aa519c41f5df27c391ecc8f26881f6b28; CNZZDATA1261815924=1394298667-1566435500-https%253A%252F%252Fwww.baidu.com%252F%7C1575418287; Hm_lpvt_72331746d85dcac3dac65202d103e5d9=1575422688; userid_secure=Yqaa7MIC+D/q2lpDSdEtFmkbjLDEQ5KYwAnr5QctOKv2f6D7v+uajbcHWJrZ5wh4noKBR51Jy6SR/11oXFdDTRrsSnk8VjiOfbsXXLFn4BDE6SmTV0als6nrbTyVlT1pL8DeWhnGq96oC50PC3+kWkIuJZwqdwynDPqiyphw9zUnF63jBLkg4prqv6bAPhNoQHneVcRWrOnZhpukfgrdEgnR03iWGA9E2OPQoTTKp5K7F1rhkQzh8id+Po3jV8r2+NTMv6a2qOWR6w/cmDjxIZPvoozE8wdz72Ymv06j0+j6dsvPnOE7POmre/jtnV0+d33NpQPoyZKRxXY2IZAvxSoqKjIwMTktMTItMDEgMDA6MDA6MDA=",
"Host": "www.jianyu360.com",
"If-Modified-Since": "Mon, 02 Dec 2019 08:55:45 GMT",
"Sec-Fetch-Mode": "navigate",
"Sec-Fetch-Site": "none",
"Upgrade-Insecure-Requests": "1",
"User-Agent": ua.random,
# "User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36",
}



def get_href(conp,total=10):
    user,passwd,host,dbname,schema=conp
    sql1='''select distinct href from "%s".gg as a  where  not exists (select 1 from "%s".gg_html as b where a.href=b.href ) limit %d'''%(schema,schema,total)
    parames=db_query(sql1,dbtype="postgresql",conp=conp)["href"].tolist()

    return parames


def get_data(href,ip):
    with open('COOKIES.json', 'r', encoding='utf8') as f:
        cookies_dict = f.read()
    cookies_dict = json.loads(cookies_dict)
    # cookies_dict={}
    # print(cookies_dict)
    proxies = {'http': 'http://%s' % ip, 'https': 'https://%s' % ip} if ip else {}

    try:
        response = requests.get(href, headers=headers, proxies=proxies, cookies=cookies_dict, timeout=40)
    except:
        return "IP失效"

    if response.status_code != 200:
        raise ConnectionError("response status code is %s"%response.status_code)

    soup=BeautifulSoup(response.text,'lxml')
    title=soup.find('title').get_text()
    if "扫码登录" in title: return "COOKIES失效"
    # print(soup)
    ext_href=soup.find('div',class_="original-text").find('a').get('href')
    return ext_href


def work(conp):
    user, passwd, host, dbname, schema = conp
    ip=get_ip()
    while True:
        time.sleep(random.random()+2)
        href_list=get_href(conp)
        if not href_list:break
        for href in href_list:
            time.sleep(random.random()+1)
            # try:
            # time.sleep(0.1)
            ext_href=get_data(href,ip)
            if ext_href=="IP失效":
                ip=get_ip()
                print("Ip失效,切换Ip:%s"%ip)
                continue

            if ext_href=="COOKIES失效":
                print("COOKIES失效,重新登录")
                ip=get_ip()
                get_cookies(ip)
                continue

            now_t=datetime.now().strftime("%Y-%m-%d %H:%M")
            sql1 = '''insert into %s.gg_html values($lch$%s$lch$,$lch$%s$lch$,$lch$%s$lch$)'''%(schema,href,ext_href,now_t)
            db_command(sql1,dbtype="postgresql", conp=conp)

            # except:
            #     # print('本次ip %s' % proxies)
            #     print('在 %s  出错'%(href))

        print("完成10个链接提取")


if __name__ == '__main__':
    conp = ["postgres", "since2015", "192.168.1.171", "postgres", "jianyu"]
    work(conp)
