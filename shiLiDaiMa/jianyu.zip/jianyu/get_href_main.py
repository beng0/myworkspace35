import re
from datetime import datetime

from zlsrc._data.data_url_quyu import quyu_dict
from lmf.dbv2 import db_command,db_write,db_query
from threading import Semaphore
sema=Semaphore()

urls_list=[]
for link in quyu_dict.keys():
    urls_list.append(link)

def clear(url):
    ext_href = re.findall('https*://(.+?)/', url)
    ext_href=ext_href[0] if ext_href else url

    ext_href_http = re.findall('(https*://.+?)/', url)
    ext_href_http = ext_href_http[0] if ext_href_http else url
    return ext_href,ext_href_http


def get_all_href(conp):
    sema.acquire()
    user, passwd, host, dbname, schema = conp
    sql='''select distinct ext_href from "%s".gg_html as a  where  not exists (select 1 from "%s".ext_href_main as b where a.ext_href=b.ext_href ) limit 10'''%(schema,schema)
    href_list=db_query(sql,dbtype="postgresql",conp=conp)["ext_href"].tolist()
    sema.release()

    return href_list


def check(conp,ext_href):
    user, passwd, host, dbname, schema = conp
    url,main_href=clear(ext_href)
    if url in urls_list:status="已存在"
    else:status="缺失"
    now_t = datetime.now().strftime("%Y-%m-%d %H:%M")
    sql1 = '''insert into %s.ext_href_main values($lch$%s$lch$,$lch$%s$lch$,$lch$%s$lch$,$lch$%s$lch$)''' % (schema,ext_href,main_href,status,now_t)
    db_command(sql1, dbtype="postgresql", conp=conp)


def work(conp):
    while True:
        href_list=get_all_href(conp)
        if not href_list:break
        for href in href_list:
            check(conp,href)
        print('完成10个提取')

if __name__ == '__main__':
    """
    create table if not exists ext_href_main(ext_href text,main_href text,status text, create_time text,primary key(ext_href))
    """

    conp = ["postgres", "since2015", "192.168.1.171", "postgres", "jianyu"]
    work(conp)