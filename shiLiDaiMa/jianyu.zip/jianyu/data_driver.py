from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from COOKIES_driver import cookies_dict
from login import get_driver


driver=get_driver()
login_url='https://www.jianyu360.com/jylab/supsearch/index.html'
driver.get(login_url)

locator = (By.XPATH, '//div[@class="lucene"]//li[1]//div[@class="left-title"]/a')
WebDriverWait(driver, 40).until(EC.presence_of_element_located(locator))

for cookie in cookies_dict:
    driver.add_cookie(cookie)

driver.get(login_url)