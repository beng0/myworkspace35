from pprint import pprint
import time, math
import re
import requests
from selenium.common.exceptions import WebDriverException
from selenium.common.exceptions import NoSuchElementException
from threading import Semaphore
from lmfscrap.fake_useragent import UserAgent
import random
import json

ua=UserAgent()
sema=Semaphore()


def get_ip():

    get_ip_url="http://zhulong.v4.dailiyun.com/query.txt?key=NPACB534AB&word=&count=1&rand=false&detail=false"

    # get_ip_url="http://ip.11jsq.com/index.php/api/entry?method=proxyServer.generate_api_url&packid=0&fa=0&fetch_key=&groupid=0&qty=1&time=1&pro=&city=&port=1&format=txt&ss=1&css=&dt=1&specialTxt=3&specialJson=&usertype=2"
    # print(self.get_ip_url)
    # get_ip_url="http://192.168.1.170/random"

    sema.acquire()
    i = 3
    try:
        url = get_ip_url
        r = requests.get(url, timeout=40, headers={'User-Agent': ua.random})
        time.sleep(1)
        ip = r.text
        while re.match("[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}:[0-9]{1,5}", ip) is None and i > 0:
            time.sleep(3 - i)
            i -= 1
            url = get_ip_url
            r = requests.get(url, timeout=40, headers={'User-Agent': ua.random})
            time.sleep(1)
            ip = r.text

    except:
        ip = {}
    finally:
        sema.release()
        if '登录IP不是白名单IP，请在用户中心添加该白名单. Please add ip to white list' in ip:
            print('ip 不在白名单')
            ip={}

    return ip.strip()



def get_cookies(ip=None):


    login_url='https://www.jianyu360.com/jylab/supsearch/index.html'
    response=requests.get(login_url)


    cookies=response.get_cookies()
    # print(cookies)

    with open('COOKIES.py','w',encoding='utf8') as f:
        f.write("cookies_dict="+str(cookies))


    COOKIES = {}
    for cookie in cookies:
        COOKIES[cookie['name']] = cookie['value']
    cookies = json.dumps(COOKIES, ensure_ascii=False)
    with open('COOKIES.json', 'w', encoding='utf8') as f:
        f.write(cookies)



if __name__ == '__main__':
    pass
    ip=get_ip()
    get_cookies(ip)



