from jianyu.login import get_cookies,get_ip
from jianyu.html_driver import run as html_drier_run
from jianyu.data_request import work as data_request_work
from jianyu.get_href_main import work as href_main_work
from jianyu.get_href_status import work as href_status_work

if __name__ == '__main__':
    conp = ["postgres", "since2015", "192.168.1.171", "postgres", "jianyu"]

    ## 登录拿cookies,可将clear_cookies 设置为 False 多次不同账号登录构建cookies池
    # ip = get_ip()
    # get_cookies(ip, clear_cookies=False)


    ## 获取剑鱼公告链接
    # data_request_work(conp)

    ## 获取公告原文链接
    html_drier_run(conp,num=1)  # num 为线程数

    ##### 提取已存入数据库中的链接
    href_main_work(conp)
    href_status_work(conp)