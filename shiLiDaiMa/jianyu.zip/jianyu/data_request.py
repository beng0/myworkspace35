import json
import re
import time

import requests
from lmf.dbv2 import db_command,db_query,db_write
from zlsrc.util.fake_useragent import UserAgent
import pandas as pd
from threading import Semaphore
from datetime import datetime
import random
from login import get_ip


sema=Semaphore()
ua=UserAgent()

post_url='https://www.jianyu360.com/front/pcAjaxReq'

headers={
"Accept": "*/*",
"Accept-Encoding": "gzip, deflate, br",
"Accept-Language": "zh-CN,zh;q=0.9",
"Connection": "keep-alive",
"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
# "Cookie": "Hm_lvt_72331746d85dcac3dac65202d103e5d9=1575257130; CNZZDATA1261815924=25711017-1575257076-%7C1575257076; UM_distinctid=16ec4a4442658-0b3f5ce9f2d523-4e4c0f20-1fa400-16ec4a4442715c; SESSIONID=e1e49cc03fbe0b7fb76d5cd09842af205cfb9cd0; Hm_lpvt_72331746d85dcac3dac65202d103e5d9=1575261836; userid_secure=Vrv2idFBkbiEB9qcMb3YLWX5A6YPDvGNxRYOnPiKM2IsXD4zng6orlTIKxKuFdfiZeBNWqbkOj51bChMj1LX7HW6Hw3OmsXA86eNy7+lZ1U0+ezuEO/edi+x4ucRTnz7vk8ktTQAqp3wTKQnPgfK8829D7g8Q+cmdiQY07OfDCstBw0h4ZWZbgPQOk7VHghG6q831VRqsU4C3y9zmrSbpoaMKc0daHI3HviRIJNbBz7o8IjmTmSfXbG/g31up7Fr+pcCNehmgPoSY9FfpUsCyoX+U9OCMf8OqWtbyb7cmfQwKx+pYxY7w9QiFYNdW9hRsHIpuOEwan5gz38/eG5nzioqKjIwMTktMTItMDEgMDA6MDA6MDA=",
"Host": "www.jianyu360.com",
"Origin": "https://www.jianyu360.com",
"Referer": "https://www.jianyu360.com/jylab/supsearch/index.html",
"Sec-Fetch-Mode": "cors",
"Sec-Fetch-Site": "same-origin",
"User-Agent": ua.random,
"X-Requested-With": "XMLHttpRequest",
}


def get_parame(conp):
    sema.acquire()
    user,passwd,host,dbname,schema=conp
    sql1='''select jytype,area,ggtype from "%s".parames where status=321 and area ~ '四川'  and ggtype ~ '标' limit 1'''%(schema)
    parames=db_query(sql1,dbtype="postgresql",conp=conp).values.tolist()

    parames=parames[0] if parames else None
    sql2="""update "%s".parames set status=100 where jytype='%s' and area = '%s' and ggtype = '%s'"""%(schema,parames[0],parames[1],parames[2])
    db_command(sql2,dbtype="postgresql",conp=conp)

    sema.release()
    return parames


def get_data(conp,parame_list,num,ip):

    # global cookies_dict
    # cookies_dict = json.loads(cookies_dict)
    cookies_dict={}
    industry,area,subtype=parame_list

    form_data={
    "pageNumber": num,
    "reqType": "lastNews",
    "searchvalue": "",
    "area": area,
    "subtype": subtype,
    "publishtime": "",
    "selectType": "title",
    "minprice": "",
    "maxprice": "",
    "industry": industry,

    }

    proxies = {'http': 'http://%s' % ip, 'https': 'https://%s' % ip} if ip else {}
    # print(proxies)
    try:
        response=requests.post(post_url,headers=headers,data=form_data,proxies=proxies,cookies=cookies_dict,timeout=40)
    except requests.exceptions.ProxyError or requests.exceptions.ConnectionError:
        return "IP失效"

    if response.status_code != 200:
        raise ConnectionError("response status code is %s"%response.status_code)

    content = response.content.decode('utf8')

    if "如有疑问请联系微信公众号后台客服" in content: return "IP失效"

    contents=response.json()['list']
    if not contents:return "内容为空"
    data=[]
    for content in contents:
        name=content.get('title')
        area=content.get('area')
        city=content.get('city')
        industry=content.get('industry')
        s_subscopeclass=content.get('s_subscopeclass')
        subtype=content.get('subtype')
        diqu = '-'.join([area, city])
        href=content.get('_id')
        href="https://www.jianyu360.com/article/content/{href_}.html?industry={industry_}".format(href_=href,industry_=industry)

        tmp=[name,href,s_subscopeclass,subtype,diqu,datetime.now().strftime("%Y-%m-%d %H:%M")]

        data.append(tmp)

    df = pd.DataFrame(data=data,columns=["name","href","jytype","ggtype","diqu","create_time"])

    db_write(df,"gg",dbtype='postgresql',conp=conp,datadict="postgresql-text",if_exists='append')

    return "数据获取成功"

def work(conp):
    user, passwd, host, dbname, schema = conp
    ip=get_ip()

    kong_error_count = 1
    while True:

        time.sleep(random.random()+1)
        parame_list=get_parame(conp)
        print("%s开始" % str(parame_list))
        industry, area, subtype = parame_list
        if not parame_list:break
        error_count = 3

        for num in range(1,2):
                time.sleep(random.random())
            # try:
                result=get_data(conp,parame_list,num,ip)

                if result == "数据获取成功":
                    error_count -=1
                    kong_error_count = 1
                if result == "IP失效":
                    ip=get_ip()
                    print("切换ip:%s"%ip)
                    print('%s 在 第%s页 出错'%(str(parame_list),num))
                if result == "内容为空":
                    kong_error_count+=1
                    print('%s 在 第%s页 获取内容为空' % (str(parame_list), num))
                if kong_error_count %60==0:raise ValueError("连续6个标签获取到空数据")
            # except:
            #
            #     # print('本次ip %s' % proxies)
            #     print('%s 在 第%s页 出错' % (str(parame_list), num))

        sql3 = """update "%s".parames set status=%d where jytype='%s' and area = '%s' and ggtype = '%s'""" % (schema,error_count, industry, area, subtype)
        db_command(sql3, dbtype="postgresql", conp=conp)
        print("%s完成"%str(parame_list))



if __name__ == '__main__':
    conp = ["postgres", "since2015", "192.168.1.171", "postgres", "jianyu"]
    work(conp)
